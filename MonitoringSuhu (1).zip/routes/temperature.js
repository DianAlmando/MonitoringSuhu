const express = require('express');
const router = express.Router();

// In-memory storage for temperature data
let temperatures = [];

// Endpoint to receive temperature data
router.post('/repl-temperature', (req, res) => {
  const { temperature } = req.body;
  if (temperature !== undefined) {
    const timestamp = new Date();
    temperatures.push({ id: temperatures.length + 1, value: temperature, timestamp });
    console.log(`Received temperature: ${temperature} at ${timestamp}`);
    res.send('Temperature received');
  } else {
    res.status(400).send('Temperature not provided');
  }
});

// Endpoint to get temperature data
router.get('/temperature', (req, res) => {
  res.json({
    temperatures: temperatures.map(t => t.value),
    timestamps: temperatures.map(t => t.timestamp),
    ids: temperatures.map(t => t.id)
  });
});

module.exports = router;
